"use client"

import { useEffect, useState } from "react"
import { Loader2 } from "lucide-react"

interface MintedName {
  name: string
  type: string
  date: string
}

const mockRecentNames: MintedName[] = [
  { name: "aresxbt69.zama", type: "Zama Cipher", date: "Dec 25, 2025" },
  { name: "cryptovault.zama", type: "Zama Sentinel", date: "Dec 22, 2025" },
  { name: "research.zama", type: "Zama Architect", date: "Dec 24, 2025" },
  { name: "privacy.zama", type: "Zama Cipher", date: "Dec 25, 2025" },
]

export function MintedNames() {
  const [recentNames, setRecentNames] = useState<MintedName[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const timer = setTimeout(() => {
      setRecentNames(mockRecentNames)
      setIsLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  return (
    <section id="minted" className="py-24 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
          <div>
            <h2 className="text-3xl font-bold tracking-tight mb-2">Recently Minted</h2>
            <p className="text-muted-foreground">The newest identities on the Zama Name Service.</p>
          </div>
          <div className="text-sm font-medium text-primary bg-primary/10 px-4 py-2 rounded-full border border-primary/20">
            Total Minted: 1,248
          </div>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 className="w-8 h-8 text-primary animate-spin" />
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {recentNames.map((item, index) => (
              <div
                key={index}
                className="bg-background p-6 rounded-2xl border border-primary/10 shadow-sm flex flex-col gap-4 hover:border-primary/30 transition-all duration-300 hover:shadow-md"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="flex items-center justify-between">
                  <div className="h-10 w-10 rounded-lg bg-primary/20 flex items-center justify-center font-bold text-primary">
                    {item.name[0].toUpperCase()}
                  </div>
                  <span className="text-[10px] font-bold uppercase tracking-widest text-primary bg-primary/10 px-2 py-1 rounded">
                    {item.type}
                  </span>
                </div>
                <div>
                  <h3 className="text-xl font-bold truncate">{item.name}</h3>
                  <p className="text-xs text-muted-foreground mt-1">Minted on: {item.date}</p>
                </div>
                <div className="pt-4 border-t flex items-center justify-between text-xs font-semibold">
                  <span className="text-muted-foreground">Ownership</span>
                  <span className="text-foreground">Permanent</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  )
}
