"use client"

import { useState, useEffect } from "react"
import { useNameService } from "@/hooks/useNameService"

export const NameRegistration = () => {
  const {
    account,
    isLoading,
    error,
    connectWallet,
    checkAvailability,
    registerName,
    getUserNameCount,
    contractAddress,
    availableWallets,
  } = useNameService()

  const [domainName, setDomainName] = useState("")
  const [isAvailable, setIsAvailable] = useState<boolean | null>(null)
  const [checking, setChecking] = useState(false)
  const [txHash, setTxHash] = useState("")
  const [userNameCount, setUserNameCount] = useState(0)

  // Check user's registered names when wallet connects
  useEffect(() => {
    if (account) {
      getUserNameCount().then(setUserNameCount).catch(console.error)
    }
  }, [account])

  const handleConnect = async () => {
    try {
      await connectWallet()
    } catch (err) {
      console.error("Connection failed:", err)
    }
  }

  const handleCheckAvailability = async () => {
    if (!domainName.trim()) return

    setChecking(true)
    setIsAvailable(null)
    setTxHash("")

    try {
      const available = await checkAvailability(domainName)
      setIsAvailable(available)
    } catch (err) {
      console.error("Check failed:", err)
    } finally {
      setChecking(false)
    }
  }

  const handleRegister = async () => {
    try {
      const result = await registerName(domainName)
      if (result.success) {
        setTxHash(result.txHash)
        setIsAvailable(false)
        // Update name count
        const count = await getUserNameCount()
        setUserNameCount(count)
      }
    } catch (err) {
      console.error("Registration failed:", err)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 p-6">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-2">FHE Name Service</h1>
          <p className="text-gray-600">Register your encrypted domain on Sepolia</p>
          <p className="text-xs text-gray-500 mt-2">Contract: {contractAddress}</p>
        </div>

        {/* Wallet Connection */}
        {!account ? (
          <div className="bg-white rounded-lg shadow-lg p-8 text-center">
            <div className="mb-6">
              <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth={1.5}
                  stroke="currentColor"
                  className="w-10 h-10 text-blue-600"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M21 12a2.25 2.25 0 00-2.25-2.25H15a3 3 0 11-6 0H5.25A2.25 2.25 0 003 12m18 0v6a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 18v-6m18 0V9M3 12V9m18 0a2.25 2.25 0 00-2.25-2.25H5.25A2.25 2.25 0 003 6v3"
                  />
                </svg>
              </div>
              <h2 className="text-2xl font-bold text-gray-800 mb-2">Connect Your Wallet</h2>
              <p className="text-gray-600">Connect your Web3 wallet to register your domain</p>
              {availableWallets.length > 0 && (
                <p className="text-sm text-gray-500 mt-2">Detected: {availableWallets.join(", ")}</p>
              )}
            </div>
            <button
              onClick={handleConnect}
              className="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
            >
              Connect Wallet
            </button>
            <p className="text-xs text-gray-500 mt-4">
              Supports MetaMask, Rabby, Coinbase Wallet, and other Web3 wallets
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Account Info */}
            <div className="bg-white rounded-lg shadow-lg p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Connected Account</p>
                  <p className="font-mono text-sm text-gray-800">
                    {account.slice(0, 6)}...{account.slice(-4)}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-gray-600">Registered Names</p>
                  <p className="text-2xl font-bold text-blue-600">{userNameCount}</p>
                </div>
              </div>
            </div>

            {/* Name Search */}
            <div className="bg-white rounded-lg shadow-lg p-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">Enter Domain Name</label>
              <div className="flex gap-3">
                <input
                  type="text"
                  value={domainName}
                  onChange={(e) => {
                    setDomainName(e.target.value.toLowerCase())
                    setIsAvailable(null)
                    setTxHash("")
                  }}
                  placeholder="myname"
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  disabled={isLoading || checking}
                />
                <button
                  onClick={handleCheckAvailability}
                  disabled={!domainName.trim() || isLoading || checking}
                  className="px-6 py-3 bg-purple-600 text-white rounded-lg font-semibold hover:bg-purple-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
                >
                  {checking ? "Checking..." : "Check"}
                </button>
              </div>

              {/* Availability Result */}
              {isAvailable !== null && (
                <div
                  className={`mt-4 p-4 rounded-lg ${
                    isAvailable ? "bg-green-50 border border-green-200" : "bg-red-50 border border-red-200"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">{isAvailable ? "✅" : "❌"}</span>
                      <div>
                        <p className={`font-semibold ${isAvailable ? "text-green-800" : "text-red-800"}`}>
                          {isAvailable ? `"${domainName}" is available!` : `"${domainName}" is already taken`}
                        </p>
                        {isAvailable && <p className="text-sm text-green-600">Registration fee: 0.001 ETH</p>}
                      </div>
                    </div>
                    {isAvailable && (
                      <button
                        onClick={handleRegister}
                        disabled={isLoading}
                        className="px-6 py-2 bg-green-600 text-white rounded-lg font-semibold hover:bg-green-700 disabled:bg-gray-300 transition-colors"
                      >
                        {isLoading ? "Minting..." : "Mint Now"}
                      </button>
                    )}
                  </div>
                </div>
              )}

              {/* Error Display */}
              {error && (
                <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
                  <p className="text-red-800 text-sm">❌ {error}</p>
                </div>
              )}

              {/* Success Display */}
              {txHash && (
                <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
                  <p className="text-green-800 font-semibold mb-2">🎉 Domain Registered Successfully!</p>
                  <a
                    href={`https://sepolia.etherscan.io/tx/${txHash}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:text-blue-700 text-sm underline break-all"
                  >
                    View on Sepolia Explorer →
                  </a>
                </div>
              )}
            </div>

            {/* Info Box */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h3 className="font-semibold text-blue-900 mb-2">ℹ️ How it works</h3>
              <ul className="text-sm text-blue-800 space-y-1">
                <li>• Enter your desired domain name</li>
                <li>• Check if it's available</li>
                <li>• Click "Mint Now" to register</li>
                <li>• Confirm transaction in MetaMask (0.001 ETH)</li>
                <li>• View your transaction on Sepolia Explorer</li>
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
