const cases = [
  {
    title: "Confidential Identities",
    description: "Manage your on-chain presence without revealing your entire transaction history to the public.",
  },
  {
    title: "Private Governance",
    description: "Vote in DAOs without revealing your stance or weighted power until the final results are tallied.",
  },
  {
    title: "Encrypted Finance",
    description: "Execute trades and manage assets in a way that is verifiable but hidden from front-running bots.",
  },
  {
    title: "Sealed Bid Auctions",
    description: "Submit bids that remain encrypted in the mempool, preventing others from gaming the system.",
  },
]

export function UseCases() {
  return (
    <section id="use-cases" className="py-24 border-b">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold tracking-tight mb-4">Real World Utility</h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            From governance to finance, .zama names unlock the next generation of private dApps.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {cases.map((useCase, index) => (
            <div
              key={index}
              className="group p-8 rounded-3xl border hover:border-primary/50 transition-all hover:shadow-xl hover:shadow-primary/5"
            >
              <div className="w-12 h-1 bg-primary mb-6 transition-all group-hover:w-full" />
              <h3 className="text-xl font-bold mb-3">{useCase.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{useCase.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
