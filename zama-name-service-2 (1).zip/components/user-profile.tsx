"use client"

import { useEffect, useState } from "react"
import { useWeb3 } from "@/contexts/web3-context"
import { Loader2, User, Hash } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export function UserProfile() {
  const { account, contract } = useWeb3()
  const [domainCount, setDomainCount] = useState<number>(0)
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    async function fetchDomainCount() {
      if (!account || !contract) {
        setDomainCount(0)
        return
      }

      setIsLoading(true)
      try {
        const count = await contract.nameCount(account)
        setDomainCount(Number(count))
        console.log("[v0] User domain count:", Number(count))
      } catch (error) {
        console.error("[v0] Failed to fetch domain count:", error)
        setDomainCount(0)
      } finally {
        setIsLoading(false)
      }
    }

    fetchDomainCount()
  }, [account, contract])

  if (!account) {
    return null
  }

  return (
    <section id="profile" className="py-24 bg-muted/30 scroll-mt-20">
      <div className="container mx-auto px-4">
        <div className="flex flex-col items-center mb-12 text-center">
          <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center mb-4">
            <User className="w-8 h-8 text-primary" />
          </div>
          <h2 className="text-3xl font-bold tracking-tight mb-2">My Profile</h2>
          <p className="text-muted-foreground">
            Connected as{" "}
            <span className="font-mono text-xs bg-muted px-2 py-1 rounded">
              {account.slice(0, 6)}...{account.slice(-4)}
            </span>
          </p>
        </div>

        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-16">
            <Loader2 className="w-8 h-8 text-primary animate-spin mb-4" />
            <p className="text-sm text-muted-foreground">Loading your profile...</p>
          </div>
        ) : (
          <div className="max-w-md mx-auto">
            <Card className="border-primary/10">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="h-10 w-10 rounded-lg bg-primary/20 flex items-center justify-center">
                    <Hash className="w-6 h-6 text-primary" />
                  </div>
                  <span className="text-[10px] font-bold uppercase tracking-widest text-primary bg-primary/10 px-2 py-1 rounded">
                    VERIFIED
                  </span>
                </div>
                <CardTitle className="text-2xl mt-4">Domain Stats</CardTitle>
                <CardDescription>Your .zama name registrations</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-baseline gap-2">
                  <span className="text-5xl font-bold text-primary">{domainCount}</span>
                  <span className="text-muted-foreground">{domainCount === 1 ? "domain" : "domains"} registered</span>
                </div>
                {domainCount === 0 ? (
                  <p className="text-sm text-muted-foreground mt-4">
                    You haven't registered any .zama domains yet. Register your first domain above to get started!
                  </p>
                ) : (
                  <p className="text-sm text-success mt-4">
                    You've successfully registered {domainCount} .zama {domainCount === 1 ? "domain" : "domains"}. All
                    your domains are secured on the blockchain!
                  </p>
                )}
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </section>
  )
}
