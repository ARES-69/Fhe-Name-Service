"use client"

import { useState, useEffect } from "react"
import { Search, Loader2, CheckCircle2, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useWeb3 } from "@/contexts/web3-context"
import { toast } from "sonner"
import { MINT_PRICE } from "@/lib/contract-abi"

export function Hero() {
  const [query, setQuery] = useState("")
  const [isChecking, setIsChecking] = useState(false)
  const [isMinting, setIsMinting] = useState(false)
  const [isAvailable, setIsAvailable] = useState<boolean | null>(null)
  const [lastCheck, setLastCheck] = useState("")

  const { account, connectWallet, mintDomain, checkDomainAvailability } = useWeb3()

  useEffect(() => {
    const timer = setTimeout(async () => {
      if (query.length >= 3 && query !== lastCheck) {
        setIsChecking(true)
        try {
          const available = await checkDomainAvailability(query)
          setIsAvailable(available)
          setLastCheck(query)
        } catch (error) {
          console.error("[v0] Error checking availability:", error)
          setIsAvailable(null)
        } finally {
          setIsChecking(false)
        }
      } else if (query.length < 3) {
        setIsAvailable(null)
      }
    }, 500)

    return () => clearTimeout(timer)
  }, [query, checkDomainAvailability, lastCheck])

  const handleMint = async () => {
    if (!account) {
      connectWallet()
      return
    }

    if (!query || query.length < 3) {
      toast.error("Domain name must be at least 3 characters")
      return
    }

    if (isAvailable === false) {
      toast.error("This domain is already taken")
      return
    }

    try {
      setIsMinting(true)
      const tx = await mintDomain(query)
      toast.info("Minting transaction submitted...")

      const receipt = await tx.wait()
      console.log("[v0] Minting successful:", receipt)

      toast.success(
        <div className="flex flex-col gap-1">
          <span className="font-bold">Mint Successful!</span>
          <span className="text-xs">Successfully minted {query}.zama</span>
        </div>,
      )

      setQuery("")
      setIsAvailable(null)
    } catch (error: any) {
      console.error("[v0] Minting failed:", error)
      const message = error.reason || error.message || "Minting failed"
      toast.error(`Error: ${message}`)
    } finally {
      setIsMinting(false)
    }
  }

  return (
    <section className="relative pt-32 pb-20 overflow-hidden zama-grid">
      <div className="container mx-auto px-4 text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary-foreground text-xs font-semibold mb-6 animate-fade-in">
          <span className="flex h-2 w-2 rounded-full bg-primary animate-pulse" />
          MINTING NOW LIVE
        </div>

        <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-6 max-w-4xl mx-auto text-balance">
          Private Identity for the <span className="text-primary italic">On Chain World</span>
        </h1>

        <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-12 text-balance leading-relaxed">
          .zama names represent encrypted, user owned identities designed for confidential applications and verifiable
          privacy.
        </p>

        <div className="max-w-2xl mx-auto relative group">
          <div className="absolute -inset-1 bg-primary/20 rounded-full blur opacity-25 group-hover:opacity-50 transition duration-1000"></div>
          <div className="relative flex items-center bg-background border-2 border-primary/10 p-2 rounded-full shadow-lg">
            <div className="pl-4 pr-2">
              {isChecking ? (
                <Loader2 className="w-5 h-5 text-primary animate-spin" />
              ) : isAvailable === true ? (
                <CheckCircle2 className="w-5 h-5 text-green-500" />
              ) : isAvailable === false ? (
                <AlertCircle className="w-5 h-5 text-destructive" />
              ) : (
                <Search className="w-5 h-5 text-primary" />
              )}
            </div>
            <input
              type="text"
              placeholder="aresxbt69"
              className="flex-1 bg-transparent border-none focus:ring-0 text-lg py-4 px-2 placeholder:text-muted-foreground/40 outline-none"
              value={query}
              onChange={(e) => setQuery(e.target.value.toLowerCase().replace(/[^a-z0-9]/g, ""))}
            />
            <div className="flex items-center gap-2 pr-2">
              <span className="text-lg font-semibold text-primary mr-4">.zama</span>
              <Button
                onClick={handleMint}
                disabled={isMinting || isChecking || (query.length > 0 && isAvailable === false)}
                className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full px-8 py-6 text-lg font-bold min-w-[160px]"
              >
                {isMinting ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Minting...
                  </>
                ) : !account ? (
                  "Connect Wallet"
                ) : (
                  "Mint Domain"
                )}
              </Button>
            </div>
          </div>

          {query.length > 0 && query.length < 3 && (
            <p className="absolute -bottom-8 left-1/2 -translate-x-1/2 text-xs text-muted-foreground">
              Min. 3 characters required
            </p>
          )}
          {isAvailable === true && (
            <p className="absolute -bottom-8 left-1/2 -translate-x-1/2 text-xs text-green-600 font-medium">
              {query}.zama is available for {MINT_PRICE} ETH
            </p>
          )}
          {isAvailable === false && (
            <p className="absolute -bottom-8 left-1/2 -translate-x-1/2 text-xs text-destructive font-medium">
              {query}.zama is already taken
            </p>
          )}
        </div>

        <div className="mt-8 flex items-center justify-center gap-4 text-sm text-muted-foreground">
          <span className="flex items-center gap-1.5">
            <div className="w-1.5 h-1.5 rounded-full bg-foreground/20" /> FHE Enabled
          </span>
          <span className="flex items-center gap-1.5">
            <div className="w-1.5 h-1.5 rounded-full bg-foreground/20" /> Zero Knowledge Proofs
          </span>
          <span className="flex items-center gap-1.5">
            <div className="w-1.5 h-1.5 rounded-full bg-foreground/20" /> Fully Private
          </span>
        </div>
      </div>
    </section>
  )
}
