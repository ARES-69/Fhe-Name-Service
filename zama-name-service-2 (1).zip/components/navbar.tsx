"use client"

import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { useWeb3 } from "@/contexts/web3-context"
import { Loader2, Wallet, User, LogOut, ExternalLink } from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

export function Navbar() {
  const { account, isConnecting, connectWallet, disconnectWallet } = useWeb3()
  const shortAddress = account ? `${account.slice(0, 6)}...${account.slice(-4)}` : null

  const scrollToProfile = () => {
    const profileSection = document.getElementById("profile")
    if (profileSection) {
      profileSection.scrollIntoView({ behavior: "smooth", block: "start" })
    }
  }

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 border-b bg-background/80 backdrop-blur-sm">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <Image src="/images/zama-logo-new.jpg" alt="Zama Logo" width={32} height={32} className="rounded-sm" />
          <span className="font-bold tracking-tight text-xl hidden sm:inline-block">
            ZAMA <span className="text-primary font-medium">NAME SERVICE</span>
          </span>
        </Link>

        <div className="hidden md:flex items-center gap-8 text-sm font-medium">
          <Link href="#why" className="hover:text-primary transition-colors">
            Why .zama
          </Link>
          <Link href="#use-cases" className="hover:text-primary transition-colors">
            Use Cases
          </Link>
          <Link href="#minted" className="hover:text-primary transition-colors">
            Recent Names
          </Link>
        </div>

        <div className="flex items-center gap-4">
          {account ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="outline"
                  className="rounded-full border-primary/20 gap-2 px-4 hover:bg-primary/5 bg-transparent"
                >
                  <div className="w-2 h-2 rounded-full bg-green-500" />
                  <span className="font-mono text-xs">{shortAddress}</span>
                  <User className="w-4 h-4 ml-1" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>My Account</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="cursor-pointer" onClick={scrollToProfile}>
                  <User className="w-4 h-4 mr-2" /> My Domains
                </DropdownMenuItem>
                <DropdownMenuItem
                  className="cursor-pointer"
                  onClick={() => window.open(`https://sepolia.etherscan.io/address/${account}`, "_blank")}
                >
                  <ExternalLink className="w-4 h-4 mr-2" /> View on Etherscan
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="text-destructive cursor-pointer" onClick={disconnectWallet}>
                  <LogOut className="w-4 h-4 mr-2" /> Disconnect
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button
              onClick={connectWallet}
              disabled={isConnecting}
              className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full px-6 font-bold flex items-center gap-2 transition-all duration-200"
            >
              {isConnecting ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <>
                  <Wallet className="w-4 h-4" />
                  Connect Wallet
                </>
              )}
            </Button>
          )}
        </div>
      </div>
    </nav>
  )
}
