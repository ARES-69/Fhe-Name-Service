import Link from "next/link"
import Image from "next/image"

export function Footer() {
  return (
    <footer className="py-12 border-t bg-background">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="md:col-span-2">
            <Link href="/" className="flex items-center gap-2 mb-6">
              <Image src="/images/zama-logo.jpg" alt="Zama Logo" width={28} height={28} className="rounded-sm" />
              <span className="font-bold tracking-tight text-lg">ZAMA NAME SERVICE</span>
            </Link>
            <p className="text-muted-foreground max-w-sm mb-6 leading-relaxed">
              Enabling confidential identities through research-grade cryptography and verifiable privacy. Built for the
              Zama ecosystem.
            </p>
            <div className="flex items-center gap-4 text-sm font-medium">
              <Link href="https://x.com/AresXBT69" target="_blank" className="hover:text-primary transition-colors">
                X
              </Link>
              <Link href="https://x.com/AresXBT69" target="_blank" className="hover:text-primary transition-colors">
                Discord
              </Link>
              <Link href="https://github.com/ARES-69" target="_blank" className="hover:text-primary transition-colors">
                GitHub
              </Link>
            </div>
          </div>

          <div>
            <h4 className="font-bold mb-6">Product</h4>
            <ul className="space-y-4 text-sm text-muted-foreground">
              <li>
                <Link href="#" className="hover:text-foreground">
                  Documentation
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-foreground">
                  Developer Portal
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-foreground">
                  API Reference
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-foreground">
                  Governance
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-6">Legal</h4>
            <ul className="space-y-4 text-sm text-muted-foreground">
              <li>
                <Link href="#" className="hover:text-foreground">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-foreground">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-foreground">
                  Cookie Policy
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-12 border-t flex flex-col items-center justify-center gap-6 text-sm text-muted-foreground text-center">
          <p>© 2025 Zama Name Service. Privacy first. Cryptographically verifiable.</p>
          <p className="flex items-center gap-2">
            Created by{" "}
            <Link href="https://x.com/AresXBT69" target="_blank" className="font-bold text-primary hover:underline">
              AresXBT
            </Link>{" "}
            with love
            <Image
              src="/images/aresxbt-logo.png"
              alt="AresXBT Logo"
              width={20}
              height={20}
              className="rounded-full inline-block ml-1"
            />
          </p>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-primary" /> Network Mainnet
            </span>
          </div>
        </div>
      </div>
    </footer>
  )
}
