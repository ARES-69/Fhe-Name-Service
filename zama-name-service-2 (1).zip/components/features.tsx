import { Shield, Cpu, Code, Layers, Lock } from "lucide-react"

const features = [
  {
    icon: Shield,
    title: "Privacy by default",
    description:
      "Public blockchains expose too much data. .zama identities are designed for applications where discretion matters most.",
  },
  {
    icon: Cpu,
    title: "Compute without disclosure",
    description:
      "Smart contracts can operate on encrypted values while remaining verifiable through Fully Homomorphic Encryption.",
  },
  {
    icon: Code,
    title: "Developer defined access", // removed dash
    description:
      "Applications decide who can decrypt what, directly in code, giving you granular control over your data.",
  },
  {
    icon: Layers,
    title: "Built for composability",
    description: "Designed to work seamlessly alongside existing public smart contracts and decentralized protocols.",
  },
  {
    icon: Lock,
    title: "Future proof security", // removed dash
    description: "Built with post quantum cryptography assumptions to ensure your identity remains secure for decades.", // removed dash
  },
]

export function Features() {
  return (
    <section id="why" className="py-24 bg-foreground text-background">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 items-start">
          <div className="md:col-span-4 sticky top-24">
            <h2 className="text-4xl font-bold tracking-tight mb-6">Why .zama Exists</h2>
            <p className="text-muted-foreground text-lg leading-relaxed">
              We're solving the transparency paradox. By moving from public-by-default to private-by-design, we enable a
              new class of confidential web3 applications.
            </p>
          </div>

          <div className="md:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className="p-8 rounded-2xl border border-background/10 bg-background/5 hover:bg-background/10 transition-colors"
              >
                <feature.icon className="w-8 h-8 text-primary mb-4" />
                <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
