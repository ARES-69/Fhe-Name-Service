"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect, useCallback } from "react"
import { ethers } from "ethers"
import { ZAMA_NAME_SERVICE_ABI, CONTRACT_ADDRESS } from "@/lib/contract-abi"

interface Web3ContextType {
  account: string | null
  isConnecting: boolean
  contract: ethers.Contract | null
  provider: ethers.BrowserProvider | null
  connectWallet: () => Promise<void>
  disconnectWallet: () => void
  mintDomain: (domainName: string) => Promise<ethers.ContractTransactionResponse>
  checkDomainAvailability: (domainName: string) => Promise<boolean>
  getUserDomains: (address: string) => Promise<string[]>
  chainId: number | null
}

const Web3Context = createContext<Web3ContextType | undefined>(undefined)

export function Web3Provider({ children }: { children: React.ReactNode }) {
  const [account, setAccount] = useState<string | null>(null)
  const [isConnecting, setIsConnecting] = useState(false)
  const [provider, setProvider] = useState<ethers.BrowserProvider | null>(null)
  const [contract, setContract] = useState<ethers.Contract | null>(null)
  const [chainId, setChainId] = useState<number | null>(null)

  const nameToHash = useCallback((name: string): string => {
    return ethers.keccak256(ethers.toUtf8Bytes(name.toLowerCase()))
  }, [])

  useEffect(() => {
    if (account && typeof window !== "undefined" && window.ethereum) {
      const ethersProvider = new ethers.BrowserProvider(window.ethereum)
      setProvider(ethersProvider)

      const contractInstance = new ethers.Contract(CONTRACT_ADDRESS, ZAMA_NAME_SERVICE_ABI, ethersProvider)
      setContract(contractInstance)
    }
  }, [account])

  const connectWallet = useCallback(async () => {
    if (typeof window === "undefined" || !window.ethereum) {
      alert("Please install MetaMask to use this app!")
      return
    }

    try {
      setIsConnecting(true)
      const ethersProvider = new ethers.BrowserProvider(window.ethereum)
      const accounts = await ethersProvider.send("eth_requestAccounts", [])
      const network = await ethersProvider.getNetwork()

      if (Number(network.chainId) !== 11155111) {
        try {
          await window.ethereum.request({
            method: "wallet_switchEthereumChain",
            params: [{ chainId: "0xaa36a7" }],
          })
        } catch (switchError: any) {
          if (switchError.code === 4902) {
            await window.ethereum.request({
              method: "wallet_addEthereumChain",
              params: [
                {
                  chainId: "0xaa36a7",
                  chainName: "Sepolia",
                  nativeCurrency: { name: "ETH", symbol: "ETH", decimals: 18 },
                  rpcUrls: ["https://sepolia.infura.io/v3/"],
                  blockExplorerUrls: ["https://sepolia.etherscan.io"],
                },
              ],
            })
          }
        }
      }

      setAccount(accounts[0])
      setChainId(Number(network.chainId))
      setProvider(ethersProvider)
    } catch (error) {
      console.error("[v0] Failed to connect wallet:", error)
      alert("Failed to connect wallet. Please try again.")
    } finally {
      setIsConnecting(false)
    }
  }, [])

  const disconnectWallet = useCallback(() => {
    setAccount(null)
    setProvider(null)
    setContract(null)
    setChainId(null)
  }, [])

  const mintDomain = useCallback(
    async (domainName: string): Promise<ethers.ContractTransactionResponse> => {
      if (!contract || !provider || !account) {
        throw new Error("Wallet not connected")
      }

      const signer = await provider.getSigner()
      const contractWithSigner = contract.connect(signer)

      const nameHash = nameToHash(domainName)

      const fee = await contractWithSigner.registrationFee()

      const tx = await contractWithSigner.registerName(nameHash, {
        value: fee,
      })

      return tx
    },
    [contract, provider, account, nameToHash],
  )

  const checkDomainAvailability = useCallback(
    async (domainName: string): Promise<boolean> => {
      if (!contract) {
        throw new Error("Contract not initialized")
      }

      try {
        const nameHash = nameToHash(domainName)
        const available = await contract.isNameAvailable(nameHash)
        return available
      } catch (error) {
        console.error("[v0] Error checking availability:", error)
        return true
      }
    },
    [contract, nameToHash],
  )

  const getUserDomains = useCallback(
    async (address: string): Promise<string[]> => {
      if (!contract) {
        throw new Error("Contract not initialized")
      }

      try {
        // This is a limitation of the current contract - it doesn't store domain names
        const count = await contract.nameCount(address)
        console.log("[v0] User has", Number(count), "domains")
        // Return empty array as contract doesn't provide domain list functionality
        return []
      } catch (error) {
        console.error("[v0] Error fetching user domains:", error)
        return []
      }
    },
    [contract],
  )

  useEffect(() => {
    if (typeof window !== "undefined" && window.ethereum) {
      const handleAccountsChanged = (accounts: string[]) => {
        if (accounts.length === 0) {
          disconnectWallet()
        } else {
          setAccount(accounts[0])
        }
      }

      const handleChainChanged = () => {
        window.location.reload()
      }

      window.ethereum.on("accountsChanged", handleAccountsChanged)
      window.ethereum.on("chainChanged", handleChainChanged)

      return () => {
        window.ethereum.removeListener("accountsChanged", handleAccountsChanged)
        window.ethereum.removeListener("chainChanged", handleChainChanged)
      }
    }
  }, [disconnectWallet])

  return (
    <Web3Context.Provider
      value={{
        account,
        isConnecting,
        contract,
        provider,
        connectWallet,
        disconnectWallet,
        mintDomain,
        checkDomainAvailability,
        getUserDomains,
        chainId,
      }}
    >
      {children}
    </Web3Context.Provider>
  )
}

export function useWeb3() {
  const context = useContext(Web3Context)
  if (context === undefined) {
    throw new Error("useWeb3 must be used within a Web3Provider")
  }
  return context
}
