"use client"

import { useState, useEffect } from "react"
import { BrowserProvider, Contract, keccak256, toUtf8Bytes } from "ethers"

const CONTRACT_ADDRESS = "0x9B25734e69D073897fA82CEF5f7A77Adb6450ea7"

// ABI based on YOUR contract
const CONTRACT_ABI = [
  "function isNameAvailable(bytes32 nameHash) view returns (bool)",
  "function registerName(bytes32 nameHash) payable",
  "function getNameOwner(bytes32 nameHash) view returns (address)",
  "function nameOwners(bytes32) view returns (address)",
  "function nameCount(address) view returns (uint256)",
  "function registrationFee() view returns (uint256)",
  "function transferName(bytes32 nameHash, address newOwner)",
  "event NameRegistered(address indexed owner, bytes32 indexed nameHash)",
]

interface WalletProvider {
  isMetaMask?: boolean
  isRabby?: boolean
  isCoinbaseWallet?: boolean
  isOkxWallet?: boolean
  request: (args: { method: string; params?: any[] }) => Promise<any>
}

export const useNameService = () => {
  const [provider, setProvider] = useState<BrowserProvider | null>(null)
  const [contract, setContract] = useState<Contract | null>(null)
  const [account, setAccount] = useState<string>("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string>("")
  const [availableWallets, setAvailableWallets] = useState<string[]>([])

  const detectWallets = () => {
    const wallets: string[] = []

    if (typeof window !== "undefined") {
      // Check for MetaMask
      if ((window as any).ethereum?.isMetaMask && !(window as any).ethereum?.isOkxWallet) {
        wallets.push("MetaMask")
      }

      // Check for Rabby
      if ((window as any).ethereum?.isRabby) {
        wallets.push("Rabby")
      }

      // Check for Coinbase Wallet
      if ((window as any).ethereum?.isCoinbaseWallet) {
        wallets.push("Coinbase Wallet")
      }

      // Check for OKX (but don't add it to the main list if other wallets exist)
      if ((window as any).ethereum?.isOkxWallet && wallets.length === 0) {
        wallets.push("OKX Wallet")
      }

      // Generic ethereum provider as fallback
      if (wallets.length === 0 && (window as any).ethereum) {
        wallets.push("Wallet")
      }
    }

    return wallets
  }

  // Initialize provider and contract
  useEffect(() => {
    const init = async () => {
      const wallets = detectWallets()
      setAvailableWallets(wallets)

      if (typeof window.ethereum !== "undefined") {
        const browserProvider = new BrowserProvider(window.ethereum)
        setProvider(browserProvider)

        const signer = await browserProvider.getSigner()
        const nameServiceContract = new Contract(CONTRACT_ADDRESS, CONTRACT_ABI, signer)
        setContract(nameServiceContract)

        // Get account if already connected
        const accounts = await window.ethereum.request({ method: "eth_accounts" })
        if (accounts[0]) setAccount(accounts[0])
      }
    }

    init()
  }, [])

  // Convert name to hash
  const nameToHash = (name: string): string => {
    return keccak256(toUtf8Bytes(name.toLowerCase()))
  }

  const connectWallet = async () => {
    try {
      setError("")
      if (!window.ethereum) {
        throw new Error("Please install a Web3 wallet (MetaMask, Rabby, etc.)")
      }

      const accounts = await window.ethereum.request({
        method: "eth_requestAccounts",
      })
      setAccount(accounts[0])

      // Re-initialize provider and contract with the selected wallet
      const browserProvider = new BrowserProvider(window.ethereum)
      setProvider(browserProvider)
      const signer = await browserProvider.getSigner()
      const nameServiceContract = new Contract(CONTRACT_ADDRESS, CONTRACT_ABI, signer)
      setContract(nameServiceContract)

      // Check network
      const chainId = await window.ethereum.request({ method: "eth_chainId" })
      if (chainId !== "0xaa36a7") {
        // Sepolia chainId
        await switchToSepolia()
      }

      return accounts[0]
    } catch (err: any) {
      setError(err.message)
      throw err
    }
  }

  // Switch to Sepolia
  const switchToSepolia = async () => {
    try {
      await window.ethereum.request({
        method: "wallet_switchEthereumChain",
        params: [{ chainId: "0xaa36a7" }],
      })
    } catch (switchError: any) {
      if (switchError.code === 4902) {
        await window.ethereum.request({
          method: "wallet_addEthereumChain",
          params: [
            {
              chainId: "0xaa36a7",
              chainName: "Sepolia",
              nativeCurrency: { name: "ETH", symbol: "ETH", decimals: 18 },
              rpcUrls: ["https://sepolia.infura.io/v3/"],
              blockExplorerUrls: ["https://sepolia.etherscan.io"],
            },
          ],
        })
      } else {
        throw switchError
      }
    }
  }

  // Check if name is available
  const checkAvailability = async (name: string): Promise<boolean> => {
    if (!contract) throw new Error("Contract not initialized")

    setIsLoading(true)
    setError("")
    try {
      const nameHash = nameToHash(name)
      const available = await contract.isNameAvailable(nameHash)
      return available
    } catch (err: any) {
      setError(err.message)
      throw err
    } finally {
      setIsLoading(false)
    }
  }

  // Register domain name
  const registerName = async (name: string) => {
    if (!contract || !account) {
      throw new Error("Wallet not connected")
    }

    setIsLoading(true)
    setError("")

    try {
      // Check availability first
      const available = await contract.isNameAvailable(nameToHash(name))
      if (!available) {
        throw new Error("Name already taken")
      }

      // Get registration fee
      const fee = await contract.registrationFee()
      const nameHash = nameToHash(name)

      // Register name
      const tx = await contract.registerName(nameHash, { value: fee })

      console.log("✅ Transaction sent:", tx.hash)
      console.log("⏳ Waiting for confirmation...")

      const receipt = await tx.wait()
      console.log("✅ Transaction confirmed!")

      return {
        success: true,
        txHash: tx.hash,
        explorerUrl: `https://sepolia.etherscan.io/tx/${tx.hash}`,
        receipt,
      }
    } catch (err: any) {
      console.error("❌ Registration error:", err)
      const errorMsg = err.message || "Registration failed"
      setError(errorMsg)
      throw new Error(errorMsg)
    } finally {
      setIsLoading(false)
    }
  }

  // Get name owner
  const getNameOwner = async (name: string): Promise<string> => {
    if (!contract) throw new Error("Contract not initialized")

    try {
      const nameHash = nameToHash(name)
      const owner = await contract.getNameOwner(nameHash)
      return owner
    } catch (err: any) {
      setError(err.message)
      throw err
    }
  }

  // Get user's name count
  const getUserNameCount = async (address?: string): Promise<number> => {
    if (!contract) throw new Error("Contract not initialized")

    const addr = address || account
    if (!addr) throw new Error("No address provided")

    try {
      const count = await contract.nameCount(addr)
      return Number(count)
    } catch (err: any) {
      setError(err.message)
      throw err
    }
  }

  return {
    account,
    isLoading,
    error,
    connectWallet,
    checkAvailability,
    registerName,
    getNameOwner,
    getUserNameCount,
    switchToSepolia,
    contractAddress: CONTRACT_ADDRESS,
    availableWallets,
  }
}
