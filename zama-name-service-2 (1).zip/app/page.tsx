import { Navbar } from "@/components/navbar"
import { Hero } from "@/components/hero"
import { Features } from "@/components/features"
import { UseCases } from "@/components/use-cases"
import { MintedNames } from "@/components/minted-names"
import { Footer } from "@/components/footer"
import { UserProfile } from "@/components/user-profile"
import { NameRegistration } from "@/components/NameRegistration"

export default function Home() {
  return (
    <main className="min-h-screen bg-background text-foreground">
      <Navbar />
      <Hero />
      <NameRegistration />
      <Features />
      <UseCases />
      <MintedNames />
      <UserProfile />
      <Footer />
    </main>
  )
}
