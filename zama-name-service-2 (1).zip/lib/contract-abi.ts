export const ZAMA_NAME_SERVICE_ABI = [
  {
    inputs: [{ internalType: "bytes32", name: "nameHash", type: "bytes32" }],
    name: "registerName",
    outputs: [],
    stateMutability: "payable",
    type: "function",
  },
  {
    inputs: [{ internalType: "bytes32", name: "nameHash", type: "bytes32" }],
    name: "isNameAvailable",
    outputs: [{ internalType: "bool", name: "", type: "bool" }],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [{ internalType: "bytes32", name: "nameHash", type: "bytes32" }],
    name: "getNameOwner",
    outputs: [{ internalType: "address", name: "", type: "address" }],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [{ internalType: "address", name: "", type: "address" }],
    name: "nameCount",
    outputs: [{ internalType: "uint256", name: "", type: "uint256" }],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [],
    name: "registrationFee",
    outputs: [{ internalType: "uint256", name: "", type: "uint256" }],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [
      { internalType: "bytes32", name: "nameHash", type: "bytes32" },
      { internalType: "address", name: "newOwner", type: "address" },
    ],
    name: "transferName",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function",
  },
  {
    anonymous: false,
    inputs: [
      { indexed: true, internalType: "address", name: "owner", type: "address" },
      { indexed: true, internalType: "bytes32", name: "nameHash", type: "bytes32" },
    ],
    name: "NameRegistered",
    type: "event",
  },
] as const

export const CONTRACT_ADDRESS = "0x9B25734e69D073897fA82CEF5f7A77Adb6450ea7"
export const MINT_PRICE = "0.001"
