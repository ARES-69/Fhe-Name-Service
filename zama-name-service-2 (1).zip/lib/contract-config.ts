export const CONTRACT_ADDRESS = "0x0000000000000000000000000000000000000000" // Replace with deployed address

export const MINT_PRICE = "0.000001"

export const CONTRACT_ABI = [
  "function mint(string name) public payable",
  "function isNameAvailable(string name) public view returns (bool)",
  "function getOwnedNames(address owner) public view returns (string[])",
  "function withdraw() public",
  "event NameMinted(address indexed owner, string name, uint256 tokenId)",
]
