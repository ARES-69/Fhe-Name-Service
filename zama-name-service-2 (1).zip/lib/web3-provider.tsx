"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect, useCallback } from "react"
import { ethers } from "ethers"

interface Web3ContextType {
  address: string | null
  isConnected: boolean
  isConnecting: boolean
  connect: () => Promise<void>
  disconnect: () => void
  provider: ethers.BrowserProvider | null
  signer: ethers.JsonRpcSigner | null
  chainId: number | null
}

const Web3Context = createContext<Web3ContextType | null>(null)

export const useWeb3 = () => {
  const context = useContext(Web3Context)
  if (!context) throw new Error("useWeb3 must be used within a Web3Provider")
  return context
}

export function Web3Provider({ children }: { children: React.ReactNode }) {
  const [address, setAddress] = useState<string | null>(null)
  const [isConnected, setIsConnected] = useState(false)
  const [isConnecting, setIsConnecting] = useState(false)
  const [provider, setProvider] = useState<ethers.BrowserProvider | null>(null)
  const [signer, setSigner] = useState<ethers.JsonRpcSigner | null>(null)
  const [chainId, setChainId] = useState<number | null>(null)

  const updateAccount = useCallback(async (newProvider: ethers.BrowserProvider) => {
    try {
      const newSigner = await newProvider.getSigner()
      const newAddress = await newSigner.getAddress()
      const network = await newProvider.getNetwork()

      setSigner(newSigner)
      setAddress(newAddress)
      setChainId(Number(network.chainId))
      setIsConnected(true)
    } catch (error) {
      console.error("[v0] Error updating account:", error)
      setAddress(null)
      setIsConnected(false)
    }
  }, [])

  const connect = async () => {
    if (typeof window.ethereum === "undefined") {
      alert("Please install MetaMask or another Web3 wallet.")
      return
    }

    try {
      setIsConnecting(true)
      const newProvider = new ethers.BrowserProvider(window.ethereum)
      await window.ethereum.request({ method: "eth_requestAccounts" })
      setProvider(newProvider)
      await updateAccount(newProvider)
    } catch (error) {
      console.error("[v0] Connection error:", error)
    } finally {
      setIsConnecting(false)
    }
  }

  const disconnect = useCallback(() => {
    setAddress(null)
    setIsConnected(false)
    setSigner(null)
    setProvider(null)
    setChainId(null)
  }, [])

  useEffect(() => {
    if (typeof window.ethereum !== "undefined") {
      const newProvider = new ethers.BrowserProvider(window.ethereum)
      setProvider(newProvider)

      window.ethereum.on("accountsChanged", (accounts: string[]) => {
        if (accounts.length > 0) {
          updateAccount(newProvider)
        } else {
          disconnect()
        }
      })

      window.ethereum.on("chainChanged", () => {
        window.location.reload()
      })
    }
  }, [updateAccount, disconnect])

  return (
    <Web3Context.Provider
      value={{
        address,
        isConnected,
        isConnecting,
        connect,
        disconnect,
        provider,
        signer,
        chainId,
      }}
    >
      {children}
    </Web3Context.Provider>
  )
}
